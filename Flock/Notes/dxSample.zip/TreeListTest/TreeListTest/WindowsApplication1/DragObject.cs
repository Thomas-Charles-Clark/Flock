﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsApplication1
{
    public class DragObject
    {
        private string[] taskNames = new string[] { "Request"};
        private int index;
        public DragObject(int index)
        {
            this.index = index;
        }
        public object DragData { get { return new object[] { taskNames[index], DateTime.Now, 0 }; } }
        public int ImageIndex { get { return index; } }
    }
}
