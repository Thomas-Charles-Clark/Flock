﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraTreeList;
using DevExpress.XtraTreeList.Nodes;
using DevExpress.XtraEditors;

namespace WindowsApplication1
{
    public partial class Form1 : Form
    {
        private DataTable CreateTable(int RowCount)
        {
            DataTable tbl = new DataTable();
            tbl.Columns.Add("ID", typeof(int));
            tbl.Columns.Add("ParentID", typeof(int));
            tbl.Columns.Add("Request", typeof(string));
            tbl.Columns.Add("LocalApprover", typeof(bool));
//            for (int i = 0; i < RowCount; i++)
//                tbl.Rows.Add(new object[] { String.Format("Name{0}", i), i + 1, 3 - i, DateTime.Now.AddDays(i), i % 3 });

            tbl.Rows.Add(new object[] { 1, 1, "User and access", null});
            tbl.Rows.Add(new object[] { 2, 1, "New user", true});
            tbl.Rows.Add(new object[] { 3, 1, "PWD reset", true});
            tbl.Rows.Add(new object[] { 4, 1, "Access rights", true});

            tbl.Rows.Add(new object[] { 5, 5, "HW related issues", null});
            tbl.Rows.Add(new object[] { 6, 5, "Desktop", false});
            tbl.Rows.Add(new object[] { 7, 5, "Printer", false});

            tbl.Rows.Add(new object[] { 8, 1, "Suspend user", true});

            return tbl;

        }

        private void SetDefaultCursor()
        {
            Cursor = Cursors.Default;
        }

        private DragObject GetDragObject(IDataObject data)
        {
            return data.GetData(typeof(DragObject)) as DragObject;
        }
        private TreeListNode GetDragNode(IDataObject data)
        {
            return data.GetData(typeof(TreeListNode)) as TreeListNode;
        }
        private TreeListNode GetVisibleNodeAbove(TreeListNode node)
        {
            int visIndex = treeList1.GetVisibleIndexByNode(node);
            return treeList1.GetNodeByVisibleIndex(visIndex - 1);
        }

        public Form1()
        {
            InitializeComponent();
            treeList1.DataSource = CreateTable(30);
            treeList1.ExpandAll();

            treeList1.FocusedNode = treeList1.FindNodeByKeyID(5);
        }

        private void treeList1_DoubleClick(object sender, EventArgs e)
        {
            Point mousePosition = MousePosition;
            TreeList treeList = (TreeList)sender;
            TreeListHitInfo hitInfo = treeList.CalcHitInfo(treeList.PointToClient(mousePosition));
            if (hitInfo.Node == null || hitInfo.HitInfoType == HitInfoType.Button) return;
            string message = string.Format("The node ID {0}", hitInfo.Node["ID"]);
            if (hitInfo.Node.ParentNode != null)
                message = string.Format("{0}\r\nThe node level is {1}",
                    message, hitInfo.Node.Level);
            XtraMessageBox.Show(message, "DX Sample", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void treeList1_DragDrop(object sender, DragEventArgs e)
        {
            TreeListHitInfo hi = treeList1.CalcHitInfo(treeList1.PointToClient(new Point(e.X, e.Y)));
            if (e.Data.GetDataPresent(typeof(TreeListNode)))
            {
                TreeListNode dragNode = e.Data.GetData(typeof(TreeListNode)) as TreeListNode;
                if (hi.Node.ParentNode != null && dragNode.HasChildren)
                {
                    e.Effect = DragDropEffects.None;
                    return;
                }

                if (hi.Node.ParentNode != null || (hi.Node.ParentNode == null && dragNode.HasChildren))
                {
                    if (hi.Node.ParentNode != dragNode.ParentNode)
                        treeList1.MoveNode(dragNode, hi.Node.ParentNode);
                    treeList1.SetNodeIndex(dragNode, treeList1.GetNodeIndex(hi.Node));
                    e.Effect = DragDropEffects.None;
                }
            }
            else
            {
                DragObject dobj = GetDragObject(e.Data);
                if (dobj != null)
                {
                    TreeListNode node = hi.Node;
                    if (hi.HitInfoType == HitInfoType.Empty || node != null)
                    {

                        node = treeList1.AppendNode(dobj.DragData, node);
                        node.StateImageIndex = dobj.ImageIndex;
                        treeList1.MakeNodeVisible(node);
                        TreeListNode parentNode = node.ParentNode;
                        if (parentNode != null && (e.KeyState & 4) != 0)
                        {
                            int index = -1;
                            if (parentNode.ParentNode != null)
                                index = parentNode.ParentNode.Nodes.IndexOf(parentNode);
                            treeList1.MoveNode(node, parentNode.ParentNode);
                            treeList1.SetNodeIndex(node, index);
                        }
                    }
                }
                e.Effect = DragDropEffects.None;
                SetDefaultCursor();
            }

        }

        private void treeList1_DragLeave(object sender, EventArgs e)
        {
            SetDefaultCursor();
        }

        private void treeList1_DragOver(object sender, DragEventArgs e)
        {
            TreeListHitInfo hi = treeList1.CalcHitInfo(treeList1.PointToClient(new Point(e.X, e.Y)));
            TreeListNode node = GetDragNode(e.Data);
            if (node == null)
            {
                if (hi.HitInfoType == HitInfoType.Empty || hi.Node != null)
                    e.Effect = DragDropEffects.Copy;
                else
                    e.Effect = DragDropEffects.None;
            }
        }

        private void treeList1_GiveFeedback(object sender, GiveFeedbackEventArgs e)
        {
            e.UseDefaultCursors = false;
        }

        private void treeList1_CalcNodeDragImageIndex(object sender, CalcNodeDragImageIndexEventArgs e)
        {
            TreeListNode node = GetDragNode(e.DragArgs.Data);
            TreeListHitInfo hi = treeList1.CalcHitInfo(treeList1.PointToClient(MousePosition));
            if (hi.Node.ParentNode != null)
                e.ImageIndex = 1;
            if (hi.Node.ParentNode == null && node.HasChildren)
                e.ImageIndex = 1;
            if (hi.Node.ParentNode != null && node.HasChildren)
                e.ImageIndex = -1;
        }

    }
}